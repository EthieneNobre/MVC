﻿/// <reference path="C:\Users\Samuel\Documents\Visual Studio 2015\Projects\FACTURA_JHONNY\WebFacturaMvc\Views/Producto/Create.cshtml" />
$("#btnNuevo").click(function (eve) {
    $("#modal-content").load("/Producto/Create");
});